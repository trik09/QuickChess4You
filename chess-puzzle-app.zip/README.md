# Chess Puzzle Elite - Prototype

A React-based chess puzzle application prototype with interactive features.

## Features

### 1. Login Page
- Clean, modern login interface
- Email/password authentication
- Social login options (Google, Facebook)
- Responsive design with chess-themed imagery

### 2. Tournament Dashboard
- Grid layout displaying tournament cards
- Tournament information (date, participants, prize pool)
- "Participate" button that navigates to puzzle page
- Navbar with links: Home, About, Why Choose Us, Contact, Puzzles

### 3. Interactive Chess Puzzle Page
- **10 Different Puzzles** - Click puzzle numbers (1-10) to switch between them
- **Interactive Chess Board** - Drag and drop pieces to make moves
- **Puzzle Types** - Mate in 1, Mate in 2, Mate in 3
- **Timer** - Countdown timer for puzzle solving
- **Actions** - Hint, Resign, and Submit buttons
- **Navigation** - Previous/Next puzzle arrows
- **Real Chess Logic** - Uses chess.js library for valid move validation

### 4. Chess Board Features
- Click a piece to select it
- Valid moves are highlighted
- Click destination square to move
- Last move is highlighted
- Proper chess piece symbols
- Board coordinates (a-h, 1-8)

## Technologies Used

- **React 19** - UI framework
- **Vite** - Build tool
- **React Router DOM** - Navigation
- **Chess.js** - Chess game logic and validation
- **CSS Modules** - Scoped styling

## Running the Application

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Project Structure

```
src/
├── components/
│   ├── Navbar/
│   │   ├── Navbar.jsx
│   │   └── Navbar.module.css
│   └── ChessBoard/
│       ├── ChessBoard.jsx
│       └── ChessBoard.module.css
├── pages/
│   ├── Login/
│   │   ├── Login.jsx
│   │   └── Login.module.css
│   ├── Dashboard/
│   │   ├── Dashboard.jsx
│   │   └── Dashboard.module.css
│   └── PuzzlePage/
│       ├── PuzzlePage.jsx
│       └── PuzzlePage.module.css
├── App.jsx
├── App.css
└── main.jsx
```

## Navigation Flow

1. **/** - Login page
2. **/dashboard** - Tournament listings
3. **/puzzle** - Interactive puzzle solver

## Static Data

Currently, all data is static:
- 4 tournament cards
- 10 chess puzzles with different difficulty levels
- Predefined puzzle solutions

## Future Enhancements

- Backend integration for user authentication
- Database for puzzles and tournaments
- Real-time tournament registration
- Puzzle solution validation
- User progress tracking
- Leaderboards
- Multiplayer features

## Development Server

The app runs on: http://localhost:5174/

## Notes for Client

- All pieces are movable on the chess board
- Chess logic validates legal moves only
- Puzzle switching works by clicking numbers 1-10
- Navigation arrows move between puzzles sequentially
- UI matches the provided design mockups
- Fully responsive design
