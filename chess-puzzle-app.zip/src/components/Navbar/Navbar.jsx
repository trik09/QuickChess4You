import { Link } from 'react-router-dom';
import styles from './Navbar.module.css';

function Navbar() {
  return (
    <nav className={styles.navbar}>
      <div className={styles.container}>
        <div className={styles.logo}>
          <span className={styles.logoIcon}>♔</span>
          <span className={styles.logoText}> Quick Chess For You</span>
        </div>
        
        <ul className={styles.navLinks}>
          <li><Link to="/dashboard">Home</Link></li>
          <li><a href="#about">About</a></li>
          <li><a href="#why-choose-us">Why Choose Us</a></li>
          <li><a href="#contact">Contact</a></li>
          <li><Link to="/puzzle">Puzzles</Link></li>
        </ul>

        <div className={styles.userSection}>
          <div className={styles.userAvatar}>
            <span>👤</span>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
