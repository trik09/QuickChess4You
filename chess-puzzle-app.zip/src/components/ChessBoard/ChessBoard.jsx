import { useState, useEffect } from 'react';
import { Chess } from 'chess.js';
import styles from './ChessBoard.module.css';

const pieceSymbols = {
  'p': '♟︎', 'n': '♞', 'b': '♝', 'r': '♜', 'q': '♛', 'k': '♚',
  'P': '♟︎', 'N': '♞', 'B': '♝', 'R': '♜', 'Q': '♛', 'K': '♚'
};

function ChessBoard({ fen, solution }) {
  const [game, setGame] = useState(new Chess(fen));
  const [selectedSquare, setSelectedSquare] = useState(null);
  const [possibleMoves, setPossibleMoves] = useState([]);
  const [lastMove, setLastMove] = useState(null);
  const [moveHistory, setMoveHistory] = useState([]);
  const [feedback, setFeedback] = useState(null);
  const [solutionIndex, setSolutionIndex] = useState(0);
  const [initialFen, setInitialFen] = useState(fen);

  useEffect(() => {
    const newGame = new Chess(fen);
    setGame(newGame);
    setSelectedSquare(null);
    setPossibleMoves([]);
    setLastMove(null);
    setMoveHistory([]);
    setFeedback(null);
    setSolutionIndex(0);
    setInitialFen(fen);
  }, [fen]);

  const files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
  const ranks = ['8', '7', '6', '5', '4', '3', '2', '1'];

  const getSquare = (file, rank) => {
    return file + rank;
  };

  const getPiece = (square) => {
    return game.get(square);
  };

  const handleSquareClick = (square) => {
    if (selectedSquare) {
      // Try to make a move
      const move = {
        from: selectedSquare,
        to: square,
        promotion: 'q' // Always promote to queen for simplicity
      };

      try {
        const result = game.move(move);
        if (result) {
          const moveNotation = result.san;
          const newHistory = [...moveHistory, moveNotation];
          setMoveHistory(newHistory);
          setLastMove({ from: selectedSquare, to: square });
          
          // Check if move matches solution
          if (solution && solutionIndex < solution.length) {
            const expectedMove = solution[solutionIndex];
            
            if (moveNotation === expectedMove || moveNotation === expectedMove + '#' || moveNotation === expectedMove + '+') {
              setFeedback('correct');
              setSolutionIndex(solutionIndex + 1);
              
              // Check if puzzle is solved
              if (solutionIndex + 1 >= solution.length || game.isCheckmate()) {
                setTimeout(() => {
                  setFeedback('solved');
                }, 500);
              } else {
                setTimeout(() => {
                  setFeedback(null);
                }, 1000);
              }
            } else {
              // Wrong move - reset board
              setFeedback('wrong');
              setTimeout(() => {
                const resetGame = new Chess(initialFen);
                setGame(resetGame);
                setMoveHistory([]);
                setSolutionIndex(0);
                setLastMove(null);
                setFeedback(null);
              }, 1500);
            }
          }
          
          setGame(new Chess(game.fen()));
        }
      } catch (e) {
        // Invalid move
      }

      setSelectedSquare(null);
      setPossibleMoves([]);
    } else {
      // Select a piece
      const piece = getPiece(square);
      if (piece && piece.color === game.turn()) {
        setSelectedSquare(square);
        const moves = game.moves({ square, verbose: true });
        setPossibleMoves(moves.map(m => m.to));
      }
    }
  };

  const isLightSquare = (fileIndex, rankIndex) => {
    return (fileIndex + rankIndex) % 2 === 0;
  };

  const isSelected = (square) => {
    return selectedSquare === square;
  };

  const isPossibleMove = (square) => {
    return possibleMoves.includes(square);
  };

  const isLastMove = (square) => {
    return lastMove && (lastMove.from === square || lastMove.to === square);
  };

  return (
    <div className={styles.boardContainer}>
      {feedback && (
        <div className={`${styles.feedback} ${styles[feedback]}`}>
          {feedback === 'correct' && '✓ Correct!'}
          {feedback === 'wrong' && '✗ Wrong Move!'}
          {feedback === 'solved' && '🎉 Puzzle Solved!'}
        </div>
      )}
      <div className={styles.board}>
        {ranks.map((rank, rankIndex) => (
          <div key={rank} className={styles.row}>
            {files.map((file, fileIndex) => {
              const square = getSquare(file, rank);
              const piece = getPiece(square);
              const isLight = isLightSquare(fileIndex, rankIndex);
              
              return (
                <div
                  key={square}
                  className={`
                    ${styles.square}
                    ${isLight ? styles.lightSquare : styles.darkSquare}
                    ${isSelected(square) ? styles.selected : ''}
                    ${isPossibleMove(square) ? styles.possibleMove : ''}
                    ${isLastMove(square) ? styles.lastMove : ''}
                  `}
                  onClick={() => handleSquareClick(square)}
                >
                  {piece && (
                    <div className={`${styles.piece} ${piece.color === 'w' ? styles.whitePiece : styles.blackPiece}`}>
                      {pieceSymbols[piece.type.toUpperCase()]}
                    </div>
                  )}
                  {fileIndex === 0 && (
                    <div className={styles.rankLabel}>{rank}</div>
                  )}
                  {rankIndex === 7 && (
                    <div className={styles.fileLabel}>{file}</div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

export default ChessBoard;
