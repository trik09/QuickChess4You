import { useState, useEffect } from 'react';
import Navbar from '../../components/Navbar/Navbar';
import ChessBoard from '../../components/ChessBoard/ChessBoard';
import styles from './PuzzlePage.module.css';

function PuzzlePage() {
  const [currentPuzzle, setCurrentPuzzle] = useState(1);
  const [timeLeft, setTimeLeft] = useState(299);

  // Timer functionality
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prevTime) => {
        if (prevTime <= 0) {
          clearInterval(timer);
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const puzzles = [
    {
      id: 1,
      type: 'Mate in 1',
      fen: 'r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 0 1',
      solution: ['Qxf7'],
      description: 'White to move and checkmate in 1 move'
    },
    {
      id: 2,
      type: 'Mate in 1',
      fen: '5rk1/5ppp/5P2/8/8/8/5PPP/4R1K1 w - - 0 1',
      solution: ['Re8'],
      description: 'White to move and checkmate in 1 move'
    },
    {
      id: 3,
      type: 'Mate in 1',
      fen: 'r1bq1rk1/ppp2ppp/2np4/2b1p2Q/2B1P3/3P1N2/PPP2PPP/RNB2RK1 w - - 0 1',
      solution: ['Qxh7'],
      description: 'White to move and checkmate in 1 move'
    },
    {
      id: 4,
      type: 'Mate in 1',
      fen: '6k1/5ppp/8/8/8/8/5PPP/4R1K1 w - - 0 1',
      solution: ['Re8'],
      description: 'White to move and checkmate in 1 move'
    },
    {
      id: 5,
      type: 'Mate in 2',
      fen: 'r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R w KQkq - 0 1',
      solution: ['Bxf7', 'Kxf7', 'Ng5'],
      description: 'White to move and checkmate in 2 moves'
    },
    {
      id: 6,
      type: 'Mate in 2',
      fen: 'r1bqkb1r/pppp1ppp/2n5/4p2Q/2BnP3/5N2/PPPP1PPP/RNB1K2R w KQkq - 0 1',
      solution: ['Qxf7', 'Kd7', 'Qd5'],
      description: 'White to move and checkmate in 2 moves'
    },
    {
      id: 7,
      type: 'Mate in 2',
      fen: 'r2qkb1r/pp2nppp/3p4/2pNN1B1/2BnP3/3P4/PPP2PPP/R2bK2R w KQkq - 0 1',
      solution: ['Nf6', 'gxf6', 'Bxf7'],
      description: 'White to move and checkmate in 2 moves'
    },
    {
      id: 8,
      type: 'Mate in 2',
      fen: '5rk1/pp3ppp/2p5/2b5/4PQ2/2P3P1/P4P1P/5RK1 w - - 0 1',
      solution: ['Qf7', 'Kh8', 'Qxf8'],
      description: 'White to move and checkmate in 2 moves'
    },
    {
      id: 9,
      type: 'Mate in 3',
      fen: 'r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/2NP1N2/PPP2PPP/R1BQK2R w KQkq - 0 1',
      solution: ['Bxf7', 'Kxf7', 'Ng5', 'Kg8', 'Qh5'],
      description: 'White to move and checkmate in 3 moves'
    },
    {
      id: 10,
      type: 'Mate in 3',
      fen: 'r2qkb1r/ppp2ppp/2n5/3Pp3/2B5/8/PPP2PPP/RNBQK2R w KQkq - 0 1',
      solution: ['Qh5', 'g6', 'Qxg6', 'hxg6', 'Bxf7'],
      description: 'White to move and checkmate in 3 moves'
    }
  ];

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handlePuzzleSelect = (puzzleNum) => {
    setCurrentPuzzle(puzzleNum);
    setTimeLeft(299); // Reset timer when switching puzzles
  };

  const handlePrevPuzzle = () => {
    if (currentPuzzle > 1) {
      setCurrentPuzzle(currentPuzzle - 1);
    }
  };

  const handleNextPuzzle = () => {
    if (currentPuzzle < puzzles.length) {
      setCurrentPuzzle(currentPuzzle + 1);
    }
  };

  const puzzle = puzzles[currentPuzzle - 1];

  return (
    <div className={styles.container}>
      <Navbar />
      
      <div className={styles.content}>
        <div className={styles.leftPanel}>
          <div className={styles.timerCard}>
            <div className={styles.timerLabel}>Time Left</div>
            <div className={styles.timer}>{formatTime(timeLeft)}</div>
          </div>

          <div className={styles.actionsCard}>
            <button className={styles.actionBtn}>
              <span>💡</span> Hint
            </button>
            <button className={styles.actionBtn}>
              <span>🔄</span> Resign
            </button>
            <button className={styles.submitBtn}>
              <span>✓</span> Submit
            </button>
          </div>
        </div>

        <div className={styles.centerPanel}>
          <div className={styles.puzzleInfo}>
            <h2>{puzzle.type}</h2>
            <p>{puzzle.description}</p>
          </div>
          <ChessBoard 
            fen={puzzle.fen}
            solution={puzzle.solution}
          />
          <div className={styles.footer}>
            © 2025 Chess Puzzler Elite. All rights reserved.
          </div>
        </div>

        <div className={styles.rightPanel}>
          <div className={styles.puzzleSelector}>
            <h3 className={styles.selectorTitle}>PUZZLESS</h3>
            <div className={styles.puzzleGrid}>
              {puzzles.map((p) => (
                <button
                  key={p.id}
                  className={`${styles.puzzleBtn} ${currentPuzzle === p.id ? styles.active : ''}`}
                  onClick={() => handlePuzzleSelect(p.id)}
                >
                  {p.id}
                </button>
              ))}
            </div>
            <div className={styles.navigation}>
              <button 
                className={styles.navBtn}
                onClick={handlePrevPuzzle}
                disabled={currentPuzzle === 1}
              >
                ◀
              </button>
              <button 
                className={styles.navBtn}
                onClick={handleNextPuzzle}
                disabled={currentPuzzle === puzzles.length}
              >
                ▶
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PuzzlePage;
